<?php
/** ArchiveFile service. PHP 7.4 compatible; no requests are run from page rendering. */
class ArchiveFile
{
    private $modx;
    private $db;
    private $prefix;
    private $storage;
    public function __construct($modx)
    {
        $this->modx = $modx;
        // xPDO::getConnection() returns an xPDOConnection wrapper, not PDO.
        // connect() populates the documented public PDO handle on MODX/xPDO.
        if (!$modx->connect() || !($modx->pdo instanceof PDO)) {
            throw new RuntimeException('Не удалось подключиться к базе данных MODX');
        }
        $this->db = $modx->pdo;
        $this->prefix = $modx->getOption('table_prefix', null, 'modx_');
        if (!preg_match('/^[a-zA-Z0-9_]*$/D', $this->prefix)) { throw new RuntimeException('Invalid table prefix'); }
        $this->storage = rtrim($modx->getOption('archivefile.storage_path', null, MODX_CORE_PATH . 'components/archivefile/storage/'), '/\\') . '/';
    }
    public function query($sql, array $params = array())
    {
        $s = $this->db->prepare($sql);
        if (!$s || !$s->execute($params)) { throw new RuntimeException('Ошибка базы данных ArchiveFile'); }
        return $s;
    }
    public function table($name)
    {
        if (!in_array($name, array('sources', 'copies'), true)) { throw new InvalidArgumentException('Invalid table'); }
        return '`' . $this->prefix . 'archivefile_' . $name . '`';
    }
    public function install()
    {
        $this->query('CREATE TABLE IF NOT EXISTS ' . $this->table('sources') . ' (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(190) NOT NULL, url TEXT NOT NULL, format VARCHAR(10) NOT NULL DEFAULT "xml",
            enabled TINYINT NOT NULL DEFAULT 1, last_success VARCHAR(35) DEFAULT NULL,
            last_daily_date VARCHAR(10) DEFAULT NULL, last_error TEXT DEFAULT NULL,
            created_at VARCHAR(35) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $this->query('CREATE TABLE IF NOT EXISTS ' . $this->table('copies') . ' (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, source_id INT UNSIGNED NOT NULL,
            filename VARCHAR(190) NOT NULL, downloaded_at VARCHAR(35) NOT NULL,
            generation_date VARCHAR(190) DEFAULT NULL, offers_count INT UNSIGNED DEFAULT NULL,
            size_bytes BIGINT UNSIGNED NOT NULL, sha256 CHAR(64) NOT NULL,
            INDEX source_copy (source_id,id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        if (!is_dir($this->storage) && !mkdir($this->storage, 0750, true)) { throw new RuntimeException('Не удалось создать папку архива'); }
        if (!is_writable($this->storage)) { throw new RuntimeException('Папка архива недоступна для записи'); }
        $deny = "Require all denied\n";
        if (file_put_contents($this->storage . '.htaccess', $deny) === false) { throw new RuntimeException('Не удалось защитить папку архива'); }
        file_put_contents($this->storage . 'index.html', '');
    }
    public function source($id)
    {
        $row = $this->query('SELECT * FROM ' . $this->table('sources') . ' WHERE id=?', array((int)$id))->fetch(PDO::FETCH_ASSOC);
        if (!$row) { throw new RuntimeException('Источник не найден'); }
        return $row;
    }
    public function sources()
    {
        $rows = $this->query('SELECT * FROM ' . $this->table('sources') . ' ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$r) {
            $copies = $this->copies($r['id']);
            $r['latest'] = isset($copies[0]) ? $copies[0] : null;
            $r['latest_url'] = $this->publicUrl($r['id']);
        }
        return $rows;
    }
    public function copies($sourceId)
    {
        $rows = $this->query('SELECT * FROM ' . $this->table('copies') . ' WHERE source_id=? ORDER BY id DESC LIMIT 5', array((int)$sourceId))->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$r) { $r['url'] = $this->publicUrl($sourceId, $r['id']); }
        return $rows;
    }
    public function publicUrl($sourceId, $copyId = null)
    {
        $site = rtrim($this->modx->getOption('site_url'), '/');
        $assets = $this->modx->getOption('assets_url', null, MODX_ASSETS_URL);
        if (preg_match('~^https?://~i', $assets)) { $base = rtrim($assets, '/'); }
        elseif (substr($assets, 0, 1) === '/') {
            $p = parse_url($site);
            $base = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '') . rtrim($assets, '/');
        } else { $base = $site . '/' . trim($assets, '/'); }
        return $base . '/components/archivefile/file.php?source=' . (int)$sourceId . ($copyId === null ? '' : '&copy=' . (int)$copyId);
    }
    public function save(array $data)
    {
        $name = trim(isset($data['name']) ? $data['name'] : '');
        $url = trim(isset($data['url']) ? $data['url'] : '');
        $format = isset($data['format']) ? $data['format'] : 'xml';
        if ($name === '' || strlen($name) > 190) { throw new RuntimeException('Укажите название длиной до 190 байт'); }
        $this->urlParts($url);
        if (!in_array($format, array('xml', 'csv', 'xlsx', 'xls', 'pdf', 'zip', 'json', 'txt'), true)) { throw new RuntimeException('Недопустимый формат'); }
        $enabled = !empty($data['enabled']) ? 1 : 0;
        $id = isset($data['id']) ? (int)$data['id'] : 0;
        if ($id) {
            $lock = $this->lock($id);
            try {
                $old = $this->source($id);
                // Previously archived files keep their own format and identity.
                $this->query('UPDATE ' . $this->table('sources') . ' SET name=?,url=?,format=?,enabled=? WHERE id=?', array($name, $url, $format, $enabled, $id));
            } finally { $this->unlock($lock); }
        } else {
            $this->query('INSERT INTO ' . $this->table('sources') . ' (name,url,format,enabled,created_at) VALUES (?,?,?,?,?)', array($name, $url, $format, $enabled, $this->now()));
            $id = (int)$this->db->lastInsertId();
        }
        return $id;
    }
    private function now() { return (new DateTimeImmutable('now', new DateTimeZone('Europe/Moscow')))->format(DateTime::ATOM); }
    private function lock($id)
    {
        $handle = fopen($this->storage . 'source-' . (int)$id . '.lock', 'c');
        if (!$handle || !flock($handle, LOCK_EX | LOCK_NB)) {
            if ($handle) { fclose($handle); }
            throw new RuntimeException('Источник уже обрабатывается. Повторите позже.');
        }
        return $handle;
    }
    private function unlock($handle) { flock($handle, LOCK_UN); fclose($handle); }
    private function urlParts($url)
    {
        $p = parse_url($url);
        if (!$p || empty($p['host']) || !isset($p['scheme']) || !in_array(strtolower($p['scheme']), array('https', 'http'), true)
            || isset($p['user']) || isset($p['pass']) || isset($p['fragment']) || strlen($url) > 4096) {
            throw new RuntimeException('Нужна прямая ссылка HTTP/HTTPS без логина и пароля');
        }
        $port = isset($p['port']) ? (int)$p['port'] : (strtolower($p['scheme']) === 'https' ? 443 : 80);
        if (!in_array($port, array(80, 443), true) || !preg_match('/^[a-zA-Z0-9.\-]+$/D', $p['host'])) {
            throw new RuntimeException('Допускаются доменные имена и порты 80/443');
        }
        $p['port'] = $port;
        return $p;
    }
    private function publicIp($host)
    {
        $ips = filter_var($host, FILTER_VALIDATE_IP) ? array($host) : gethostbynamel($host);
        if (!$ips) { throw new RuntimeException('Не удалось определить адрес сервера'); }
        foreach ($ips as $ip) {
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)
                && !preg_match('/^(0\.|127\.|169\.254\.|100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.)/', $ip)) { return $ip; }
        }
        throw new RuntimeException('Загрузка с локальных и служебных адресов запрещена');
    }
    private function redirectUrl($base, $location)
    {
        if (preg_match('~^https?://~i', $location)) { return $location; }
        $p = $this->urlParts($base);
        if (substr($location, 0, 2) === '//') { return $p['scheme'] . ':' . $location; }
        $origin = $p['scheme'] . '://' . $p['host'] . ':' . $p['port'];
        if (substr($location, 0, 1) === '/') { return $origin . $location; }
        if (substr($location, 0, 1) === '?') { return $origin . (isset($p['path']) ? $p['path'] : '/') . $location; }
        $path = isset($p['path']) ? $p['path'] : '/';
        return $origin . substr($path, 0, strrpos($path, '/') + 1) . $location;
    }
    protected function download($url, $file)
    {
        if (!extension_loaded('curl')) { throw new RuntimeException('Требуется расширение PHP cURL'); }
        $max = max(1, min(1024, (int)$this->modx->getOption('archivefile.max_size_mb', null, 50))) * 1024 * 1024;
        for ($redirects = 0; $redirects <= 5; $redirects++) {
            $p = $this->urlParts($url);
            $ip = $this->publicIp($p['host']);
            $stream = fopen($file, 'wb');
            if (!$stream) { throw new RuntimeException('Не удалось создать временный файл'); }
            $size = 0; $location = null;
            $ch = curl_init($url);
            curl_setopt_array($ch, array(
                CURLOPT_FOLLOWLOCATION => false, CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_TIMEOUT => 120,
                CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
                CURLOPT_PROXY => '', CURLOPT_USERAGENT => 'ArchiveFile/1.0 (MODX)', CURLOPT_ENCODING => '',
                CURLOPT_RESOLVE => array($p['host'] . ':' . $p['port'] . ':' . $ip),
                CURLOPT_HEADERFUNCTION => function ($ch, $line) use (&$location) {
                    if (stripos($line, 'Location:') === 0) { $location = trim(substr($line, 9)); }
                    return strlen($line);
                },
                CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use ($stream, &$size, $max) {
                    $size += strlen($chunk);
                    if ($size > $max) { return 0; }
                    $written = fwrite($stream, $chunk);
                    return $written === false ? 0 : $written;
                }
            ));
            try {
                $ok = curl_exec($ch);
                $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $error = curl_error($ch);
            } finally { curl_close($ch); fclose($stream); }
            if (!$ok) { throw new RuntimeException($size > $max ? 'Превышен максимальный размер файла' : 'Ошибка скачивания: ' . $error); }
            if ($status >= 300 && $status < 400 && $location !== null) {
                $url = $this->redirectUrl($url, $location);
                continue;
            }
            if ($status !== 200) { throw new RuntimeException('Сервер вернул HTTP ' . $status); }
            if (!$size) { throw new RuntimeException('Получен пустой файл'); }
            return;
        }
        throw new RuntimeException('Слишком много перенаправлений');
    }
    public static function xmlMetadata($file)
    {
        if (!class_exists('XMLReader')) { throw new RuntimeException('Требуется PHP XMLReader'); }
        $oldErrors = libxml_use_internal_errors(true);
        $oldLoader = libxml_disable_entity_loader(true);
        libxml_clear_errors();
        $reader = new XMLReader();
        $count = 0; $date = null; $root = false;
        try {
            // XMLReader may not open filenames with the global entity loader disabled;
            // open an already-read string and never resolve external entities.
            $content = file_get_contents($file);
            if ($content === false || !$reader->XML($content, null, LIBXML_NONET)) { throw new RuntimeException('Не удалось прочитать XML'); }
            $reader->setParserProperty(XMLReader::SUBST_ENTITIES, false);
            $reader->setParserProperty(XMLReader::LOADDTD, false);
            while ($reader->read()) {
                if ($reader->nodeType === XMLReader::DOC_TYPE) { throw new RuntimeException('XML с DTD не поддерживается'); }
                if ($reader->nodeType === XMLReader::ELEMENT) {
                    $root = true;
                    if ($reader->localName === 'offer' && $reader->getAttribute('internal-id') !== null) { $count++; }
                    if ($reader->localName === 'generation-date' && $date === null) { $date = substr(trim($reader->readString()), 0, 190); }
                }
            }
            foreach (libxml_get_errors() as $error) {
                if ($error->level >= LIBXML_ERR_ERROR) { throw new RuntimeException('Некорректный XML: ' . trim($error->message)); }
            }
            if (!$root) { throw new RuntimeException('XML не содержит корневого элемента'); }
            return array('generation_date' => $date === '' ? null : $date, 'offers_count' => $count);
        } finally {
            $reader->close(); libxml_clear_errors(); libxml_use_internal_errors($oldErrors); libxml_disable_entity_loader($oldLoader);
        }
    }
    public function fetch($id, $daily = false)
    {
        $id = (int)$id;
        $lock = $this->lock($id); $temp = null; $final = null; $committed = false;
        try {
            $source = $this->source($id);
            $today = substr($this->now(), 0, 10);
            if ($daily && (!$source['enabled'] || $source['last_daily_date'] === $today)) { return array('skipped' => true); }
            $temp = tempnam($this->storage, 'tmp-');
            if ($temp === false) { throw new RuntimeException('Нет места для временного файла'); }
            $this->download($source['url'], $temp);
            $meta = $source['format'] === 'xml' ? self::xmlMetadata($temp) : array('generation_date' => null, 'offers_count' => null);
            $head = file_get_contents($temp, false, null, 0, 512);
            if (preg_match('~^\s*(?:<!DOCTYPE\s+html|<html\b)~i', $head)) { throw new RuntimeException('Вместо файла получена HTML-страница'); }
            $filename = 'source-' . $id . '-' . gmdate('Ymd-His') . '-' . bin2hex(random_bytes(8)) . '.' . $source['format'];
            $final = $this->storage . $filename;
            $size = filesize($temp); $hash = hash_file('sha256', $temp); $now = $this->now();
            if (!rename($temp, $final)) { throw new RuntimeException('Не удалось сохранить файл'); }
            $temp = null;
            $this->db->beginTransaction();
            $this->query('INSERT INTO ' . $this->table('copies') . ' (source_id,filename,downloaded_at,generation_date,offers_count,size_bytes,sha256) VALUES (?,?,?,?,?,?,?)',
                array($id, $filename, $now, $meta['generation_date'], $meta['offers_count'], $size, $hash));
            $newId = (int)$this->db->lastInsertId();
            $this->query('UPDATE ' . $this->table('sources') . ' SET last_success=?,last_error=NULL' . ($daily ? ',last_daily_date=?' : '') . ' WHERE id=?',
                $daily ? array($now, $today, $id) : array($now, $id));
            $all = $this->query('SELECT id,filename FROM ' . $this->table('copies') . ' WHERE source_id=? ORDER BY id DESC', array($id))->fetchAll(PDO::FETCH_ASSOC);
            $old = array_slice($all, 5);
            foreach ($old as $copy) { $this->query('DELETE FROM ' . $this->table('copies') . ' WHERE id=?', array($copy['id'])); }
            $this->db->commit(); $committed = true;
            foreach ($old as $copy) {
                $path = $this->storage . basename($copy['filename']);
                if (is_file($path) && !unlink($path)) { $this->modx->log(modX::LOG_LEVEL_ERROR, 'ArchiveFile: cannot remove expired copy ' . $copy['id']); }
            }
            // Retry cleanup of orphaned files from earlier interrupted runs.
            $keep = array_column(array_slice($all, 0, 5), 'filename');
            foreach (glob($this->storage . 'source-' . $id . '-*.*') as $path) {
                if (!in_array(basename($path), $keep, true) && is_file($path)) { @unlink($path); }
            }
            return array('id' => $newId, 'generation_date' => $meta['generation_date'], 'offers_count' => $meta['offers_count']);
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) { $this->db->rollBack(); }
            if ($final && !$committed && is_file($final)) { @unlink($final); }
            $this->query('UPDATE ' . $this->table('sources') . ' SET last_error=? WHERE id=?', array(substr($e->getMessage(), 0, 2000), $id));
            throw $e;
        } finally {
            if ($temp && is_file($temp)) { @unlink($temp); }
            $this->unlock($lock);
        }
    }
    public function file($sourceId, $copyId = null)
    {
        $this->source($sourceId);
        $sql = 'SELECT * FROM ' . $this->table('copies') . ' WHERE source_id=?';
        $args = array((int)$sourceId);
        if ($copyId !== null) { $sql .= ' AND id=?'; $args[] = (int)$copyId; }
        $row = $this->query($sql . ' ORDER BY id DESC LIMIT 1', $args)->fetch(PDO::FETCH_ASSOC);
        if (!$row) { throw new RuntimeException('Копия не найдена или уже удалена'); }
        $path = $this->storage . basename($row['filename']);
        // Open before releasing to the web server so rotation cannot break a running download.
        $handle = @fopen($path, 'rb');
        if (!$handle) { throw new RuntimeException('Файл недоступен'); }
        return array($row, $handle);
    }
}
