(function () {
  'use strict';
  function start() {
    var root = document.getElementById('archivefile');
    if (!root) return;
    var config = window.ArchiveFileConfig, sources = [], current = 0, busy = false;
    var form = document.getElementById('fa-form');
    var message = document.getElementById('fa-message');
    function notify(text, error) { message.textContent = text; message.className = error ? 'fa-error' : 'fa-ok'; }
    function api(action, data) {
      var body = new URLSearchParams(data || {}); body.set('action', action); body.set('csrf', config.csrf);
      return fetch(config.connector, {method: 'POST', credentials: 'same-origin', body: body}).then(function (r) {
        return r.json();
      }).then(function (r) { if (!r.success) throw new Error(r.message || 'Ошибка сервера'); return r.data; });
    }
    function cell(row, value, cls) { var td = document.createElement('td'); td.textContent = value === null || value === undefined ? '—' : value; if (cls) td.className = cls; row.appendChild(td); return td; }
    function button(text, fn) { var b = document.createElement('button'); b.type = 'button'; b.textContent = text; b.onclick = fn; return b; }
    function date(value) { if (!value) return '—'; var d = new Date(value); return isNaN(d.getTime()) ? value : d.toLocaleString('ru-RU', {timeZone: 'Europe/Moscow'}); }
    function copy(url) {
      function fallback() {
        var t = document.createElement('textarea'); t.value = url; root.appendChild(t); t.select();
        var ok = document.execCommand('copy'); t.remove();
        if (ok) notify('Ссылка скопирована'); else window.prompt('Скопируйте ссылку:', url);
      }
      if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(url).then(function () { notify('Ссылка скопирована'); }).catch(fallback);
      else fallback();
    }
    function setBusy(value) { busy = value; root.querySelectorAll('button').forEach(function (b) { b.disabled = value; }); }
    function load() {
      return api('list').then(function (data) {
        sources = data.sources;
        document.getElementById('fa-cron').textContent = data.cron;
        var tbody = document.getElementById('fa-sources'); tbody.textContent = '';
        sources.forEach(function (s) {
          var row = document.createElement('tr'), last = s.latest || {};
          cell(row, s.name); cell(row, date(last.generation_date)); cell(row, last.offers_count); cell(row, date(s.last_success));
          cell(row, s.last_error || (!s.enabled || s.enabled === '0' ? 'Отключено' : s.last_success ? 'Успешно' : 'Ещё не скачивалось'), s.last_error ? 'fa-error' : 'fa-ok');
          cell(row, '').appendChild(button('Открыть', function () { if (!busy) open(s); })); tbody.appendChild(row);
        });
        if (!sources.length) { var tr = document.createElement('tr'); cell(tr, 'Добавьте первую ссылку').colSpan = 6; tbody.appendChild(tr); }
      });
    }
    function loadCopies(id) {
      return api('copies', {id: id}).then(function (rows) {
        if (Number(form.elements.id.value) !== Number(id)) return;
        var tbody = document.getElementById('fa-copies'); tbody.textContent = '';
        rows.forEach(function (c, i) {
          var tr = document.createElement('tr'); cell(tr, date(c.downloaded_at)); cell(tr, date(c.generation_date));
          var count = c.offers_count;
          if (count !== null && rows[i + 1] && rows[i + 1].offers_count !== null) {
            var delta = Number(count) - Number(rows[i + 1].offers_count); count = count + ' (' + (delta > 0 ? '+' : '') + delta + ')';
          }
          cell(tr, count); cell(tr, (Number(c.size_bytes) / 1024).toLocaleString('ru-RU', {maximumFractionDigits: 1}) + ' КБ');
          var td = cell(tr, ''), actions = document.createElement('div'); actions.className = 'fa-actions';
          var a = document.createElement('a'); a.href = c.url; a.textContent = 'Скачать'; a.target = '_blank'; a.rel = 'noopener'; actions.appendChild(a);
          actions.appendChild(button('Копировать ссылку', function () { copy(c.url); })); td.appendChild(actions); tbody.appendChild(tr);
        });
        if (!rows.length) { var tr = document.createElement('tr'); cell(tr, 'Сохранённых копий пока нет').colSpan = 5; tbody.appendChild(tr); }
      });
    }
    function open(s) {
      current = s ? Number(s.id) : 0;
      document.getElementById('fa-detail').hidden = false;
      document.getElementById('fa-title').textContent = s ? s.name : 'Новая ссылка';
      form.elements.id.value = current; form.elements.name.value = s ? s.name : ''; form.elements.url.value = s ? s.url : '';
      form.elements.format.value = s ? s.format : 'xml'; form.elements.enabled.checked = s ? Number(s.enabled) === 1 : true;
      document.getElementById('fa-fetch').hidden = !current;
      document.getElementById('fa-latest').hidden = !current;
      document.getElementById('fa-latest-url').value = s ? s.latest_url : '';
      document.getElementById('fa-copies').textContent = '';
      if (current) loadCopies(current).catch(function (e) { notify(e.message, true); });
      form.elements.name.focus();
    }
    document.getElementById('fa-add').onclick = function () { open(null); };
    document.getElementById('fa-close').onclick = function () { document.getElementById('fa-detail').hidden = true; current = 0; };
    document.getElementById('fa-copy-latest').onclick = function () { copy(document.getElementById('fa-latest-url').value); };
    form.onsubmit = function (e) {
      e.preventDefault(); if (busy) return; setBusy(true);
      api('save', {id: form.elements.id.value, name: form.elements.name.value, url: form.elements.url.value, format: form.elements.format.value, enabled: form.elements.enabled.checked ? 1 : 0})
        .then(function (r) { return load().then(function () { open(sources.find(function (s) { return Number(s.id) === Number(r.id); })); notify('Настройки сохранены'); }); })
        .catch(function (e) { notify(e.message, true); }).finally(function () { setBusy(false); });
    };
    document.getElementById('fa-fetch').onclick = function () {
      if (busy || !current) return;
      var id = current; setBusy(true); notify('Скачивание и проверка файла…');
      api('fetch', {id: id}).then(function () { return load(); }).then(function () { return loadCopies(id); })
        .then(function () { notify('Файл сохранён. В архиве оставлены последние 5 копий.'); })
        .catch(function (e) { notify(e.message, true); load().catch(function () {}); })
        .finally(function () { setBusy(false); });
    };
    load().catch(function (e) { notify(e.message, true); });
  }
  if (window.Ext) Ext.onReady(start); else if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
}());
