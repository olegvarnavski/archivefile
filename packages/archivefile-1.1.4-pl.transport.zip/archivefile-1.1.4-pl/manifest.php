<?php return array(
'manifest-version' => '1.1',
'manifest-attributes' => array(
'package_name' => 'Archive File',
'package_version' => '1.1.4',
'readme' => '# Archive File 1.1.4 — восстановление

Возвращает интерфейс и сервис из версии 1.0.1, которая работала на вашем сайте. Номер 1.1.4 нужен для установки поверх версий 1.1.x.

Установите через менеджер пакетов как обновление, не удаляя компонент. Очистите кеш MODX, перезагрузите менеджер Ctrl+F5, откройте «Компоненты → Archive File». Существующая задача cron остаётся прежней.

Настройки и таблицы совместимы. Установщик не удаляет источники, копии или публичные файлы и не добавляет демонстрационные источники. Закрытые копии продолжают храниться в той же папке.

Возвращены функции 1.0.1: добавление и изменение источников, включение ежедневного скачивания, ручное «Скачать сейчас», пять копий, показатели XML, копирование ссылок. Новый аккордеон и удаление источников временно отсутствуют. Ссылки снова выдаются через PHP-обработчик 1.0.1; статические файлы новых версий остаются на диске, но эта версия их не обновляет.

Уже удалённые предыдущими пакетами архивы не восстанавливаются этим обновлением — нужна резервная копия сервера. Удалённый источник можно добавить заново и скачать текущий файл.
',
'license' => 'MIT License

Copyright (c) 2026 ArchiveFile contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
'changelog' => '1.1.4-pl: Recovery release using the working 1.0.1 service and interface. Existing source data is preserved; no automatic seed or deletion.'
),
'manifest-vehicles' => array(
array(
'vehicle_package' => 'transport',
'vehicle_class' => 'xPDOScriptVehicle',
'class' => 'xPDOScriptVehicle',
'guid' => '2718dd98d2d77fee021d67b8d59d89ad',
'native_key' => '2718dd98d2d77fee021d67b8d59d89ad',
'filename' => 'xPDOScriptVehicle/becedfbc8761e01e8719f16b9e9bfdb4.vehicle'
)
)
);
