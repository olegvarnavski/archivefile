<?php return array(
'manifest-version' => '1.1',
'manifest-attributes' => array(
'package_name' => 'Archive File',
'package_version' => '1.2.2',
'readme' => '# Archive File для MODX Revolution

Компонент MODX для скачивания файлов по прямым ссылкам, ежедневного архивирования и хранения последних **пяти успешных копий каждого источника**. Источники добавляются через менеджер MODX: своей ссылке можно задать понятное название, включить расписание и скачать файл вручную.

## Состояние проекта

| Версия | Статус |
|---|---|
| 1.0.1 | Интерфейс и скачивание подтверждены пользователем на сайте |
| 1.1.0–1.1.3 | Проблемные промежуточные версии; не использовать |
| 1.1.4 | Пакет восстановления на основе 1.0.1; работа подтверждена пользователем |
| 1.2.0 | Скачивание подтверждено на сайте; настройки не открываются, прокрутка не работает. Локальные тесты эти ошибки не выявили |

Для действующего сайта подтверждённая основа — **1.1.4**. Версию **1.2.0** сначала проверить на тестовой копии MODX. Имитация объектов MODX в тестах не заменяет установку на настоящем MODX/MySQL.

## Исправление 1.2.1

Установлена причина ошибок интерфейса: пункт меню MODX и контейнер компонента имели одинаковый ID archivefile. Контейнер переименован в archivefile-app; логика скачивания не меняется. Регрессионный тест включает пункт меню с прежним ID. Проверка на сайте после установки ещё требуется.

## Возможности 1.2.0

- Несколько прямых HTTP/HTTPS ссылок с произвольными названиями.
- XML, CSV, XLSX, XLS, PDF, ZIP, JSON и TXT.
- Ежедневная загрузка через cron; выключение расписания для отдельных источников.
- Принудительная загрузка, включая отключённые источники и неизменившиеся файлы.
- Последние пять успешных копий, размер, время загрузки и статус ошибки.
- Для XML: `generation-date`, число элементов `offer` с атрибутом `internal-id`, изменение числа предложений между копиями.
- Настройки и история раскрываются под строкой источника: сначала **«Настройки источника»**, затем **«Последние 5 копий»**.
- Иконки с подсказками: настройки, обновить, скачать, копировать, удалить.
- Удаление источника вместе с его архивом после подтверждения.
- Вертикальное выравнивание ячеек по центру и прокрутка страницы.
- Обычный публичный файл последней успешной версии:

```text
https://example.org/assets/archivefile/17/lastfile.xml
```

ID источника задаёт папку, расширение соответствует формату. Переименование источника не меняет адрес. Исторические копии выдаются через `assets/components/archivefile/file.php?source=17&copy=123`.

## Требования

- MODX Revolution 2.8.5-pl — целевая версия.
- PHP 7.4+ с cURL, XMLReader и PDO MySQL.
- MySQL, поддерживаемый целевой установкой MODX.
- Права PHP на запись в папки компонента и `assets/archivefile/`.
- Возможность запуска CLI PHP по расписанию хостинга.

Другие версии MODX отдельно не проверены. Минимальная версия PHP описывает совместимость компонента, а не срок поддержки самого PHP.

## Установка и обновление

1. Сохранить резервную копию сайта и базы или использовать тестовую копию.
2. Загрузить `packages/archivefile-1.2.0-pl.transport.zip` через установщик пакетов MODX.
3. Установить пакет; для существующего компонента выполнить обновление без удаления.
4. Очистить кеш MODX и перезагрузить менеджер `Ctrl+F5`.
5. Открыть **«Компоненты → Archive File»**.
6. Добавить источник, выбрать формат, выполнить ручную загрузку.
7. Проверить дату, счётчик, скачивание исторической копии и постоянный `lastfile`.
8. Добавить команду из блока расписания в cron.

Обновления 1.1.4 и 1.2.0 не удаляют источники и архивы. Демонстрационные ссылки автоматически не добавляются. Пакет создаёт собственные таблицы, namespace, пункт меню и системные настройки; ресурсы, шаблоны и чанки публичного сайта не меняются.

**Важно про старые версии:** установщики 1.1.0–1.1.1 удаляли неизменённый первоначальный источник вместе с архивом. Уже удалённые данные возвращаются только из резервной копии; исходную ссылку можно добавить заново для последующих загрузок.

## Cron

Команда в интерфейсе использует `/usr/bin/php7.4` и фактический MODX_CORE_PATH. Путь к PHP можно изменить системной настройкой `archivefile.cron_php_path`; обновления сохраняют её значение. Пользователь сообщил, что 1.2.1 работает после исправления ID меню.


Пример команды:

```sh
/usr/bin/php /полный/путь/core/components/archivefile/cron.php
```

Пример расписания:

```cron
0 3 * * * /usr/bin/php /полный/путь/core/components/archivefile/cron.php
```

Пример означает 03:00 **в часовом поясе cron хостинга**. Для 03:00 по Москве выбрать соответствующее время в панели. Компонент использует `Europe/Moscow` для дат и ограничения одного ежедневного успешного запуска на источник. Ошибки могут быть повторены следующим запуском. Ручная загрузка не блокируется этим ограничением. Использовать CLI PHP с нужными расширениями; версия PHP сайта и CLI может отличаться.

## Хранение и ссылки

Основной архив расположен в закрытой папке `core/components/archivefile/storage/` или по настройке `archivefile.storage_path`. Последняя копия дополнительно публикуется в `assets/archivefile/{id}/lastfile.{format}`. Публичный файл доступен без сессии менеджера; включать эту функцию только для файлов, которые можно отдавать по открытой ссылке.

Историческая ссылка перестаёт работать после удаления копии при ротации. Постоянный адрес обновляется после успешной загрузки. Отключение ежедневного скачивания не удаляет файл. Смена формата существующего источника в 1.2.0 запрещена для сохранения адреса — добавить другой источник.

Для Apache компонент записывает правила запрета просмотра каталога и `Cache-Control: no-cache`. Nginx и CDN не читают `.htaccess`: исключить эту папку из длительного кеширования на уровне сервера, если оно используется.

## Разработка

```sh
python3 build/build.py
php tests/service.php
php tests/install.php
npm install
npm test
```

Сборка создаёт `dist/archivefile-1.2.0-pl.transport.zip`. Исходники и тесты включаются в пакет в папку `SOURCE`. Проверка установщика использует штатный xPDO script vehicle с имитацией MODX и SQLite; фикстуры в `tests/fixtures/modx`. Для тестов PHP нужен также PDO SQLite. UI-тест использует jsdom и имитацию ответов API.

Дополнительно проверить синтаксис всех PHP-файлов именно на PHP 7.4. Перед каждым выпуском обязательна ручная проверка на тестовом MODX/MySQL. Полный перечень проверок — [docs/TESTING.md](docs/TESTING.md).

## Документация

- [Устройство компонента](docs/ARCHITECTURE.md)
- [Проверки и диагностика](docs/TESTING.md)
- [Дальнейшие задачи](docs/ROADMAP.md)
- [История версий](CHANGELOG.md)
- [Правила разработки](AGENTS.md)

Изменения делать небольшими ветками и оформлять через Pull Request: проблема, изменение поведения, проверки, ограничения. Подтверждённую версию восстановления хранить отдельно от экспериментальной.
',
'license' => 'MIT License

Copyright (c) 2026 ArchiveFile contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
'changelog' => '1.2.2-pl: Working 1.1.4 controller and loader retained; inline settings and history, icons, source deletion, forced download, vertical alignment and per-source lastfile static URLs. No source removal on upgrade.'
),
'manifest-vehicles' => array(
array(
'vehicle_package' => 'transport',
'vehicle_class' => 'xPDOScriptVehicle',
'class' => 'xPDOScriptVehicle',
'guid' => 'b9406d39aa752a9597c39adb03cd222a',
'native_key' => 'b9406d39aa752a9597c39adb03cd222a',
'filename' => 'xPDOScriptVehicle/3ce5403f3994cbc02b5b63f9b3b0a6ab.vehicle'
)
)
);
