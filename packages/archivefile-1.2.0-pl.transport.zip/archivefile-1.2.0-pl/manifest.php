<?php return array(
'manifest-version' => '1.1',
'manifest-attributes' => array(
'package_name' => 'Archive File',
'package_version' => '1.2.0',
'readme' => '# Archive File 1.2.0-pl

MODX Revolution 2.8.5-pl / PHP 7.4+. Обновление на основе рабочей 1.1.4, с тем же способом вывода страницы и подключения скриптов.

Установите транспортный пакет как обновление, не удаляя компонент. Очистите кеш MODX, нажмите Ctrl+F5 и откройте «Компоненты → Archive File». Источники, настройки, таблицы и архивы сохраняются. Установщик не добавляет и не удаляет источники. Команда cron прежняя.

Настройки раскрываются под строкой источника. Сначала заголовок «Настройки источника», ниже «Последние 5 копий». Иконки снабжены подсказками: настройки, принудительно скачать, скачать файл, копировать ссылку, удалить. Удаление источника и его архива требует подтверждения. Кнопка ↻ скачивает новую копию независимо от расписания, состояния ежедневного скачивания и совпадения содержимого.

Постоянная ссылка: https://ваш-домен/assets/archivefile/ID/lastfile.xml. Расширение соответствует формату источника. Это обычный публичный файл без PHP и параметров, заменяется после успешной загрузки. При обновлении создаётся из последней сохранённой копии. Переименование источника не меняет адрес. Для смены формата создайте новый источник. Папка assets/archivefile должна быть доступна для записи. Для Apache добавлен no-cache; для Nginx/CDN при наличии кеширования настройте эту папку отдельно.

Исторические копии по-прежнему выдаются обработчиком file.php, пока входят в последние пять. Ошибки загрузки, XML и публикации lastfile сохраняют прежний архив. XML: generation-date и количество offer с атрибутом internal-id. Для других типов архивирование без XML-показателей.

Прокрутка ограничена доступной высотой страницы; ячейки таблиц выровнены по центру по вертикали. Шаблоны и ресурсы сайта не меняются.

Требуются cURL, XMLReader, PDO MySQL. Проверены синтаксис PHP 7.4, сервис, интерфейс, установка и обновление через xPDO в тестовом окружении. Это не проверка на живом сайте MODX/MySQL.

Исходники и тесты включены в SOURCE. Сборка: python3 build/build.py.
',
'license' => 'MIT License

Copyright (c) 2026 ArchiveFile contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
'changelog' => '1.2.0-pl: Working 1.1.4 controller and loader retained; inline settings and history, icons, source deletion, forced download, vertical alignment and per-source lastfile static URLs. No source removal on upgrade.'
),
'manifest-vehicles' => array(
array(
'vehicle_package' => 'transport',
'vehicle_class' => 'xPDOScriptVehicle',
'class' => 'xPDOScriptVehicle',
'guid' => '858e1f0b8f6c6ddfc2f905a7d1f176ad',
'native_key' => '858e1f0b8f6c6ddfc2f905a7d1f176ad',
'filename' => 'xPDOScriptVehicle/34a471d7da003536eb94666bd8967823.vehicle'
)
)
);
